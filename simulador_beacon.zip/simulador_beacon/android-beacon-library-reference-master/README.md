## Overview

This is the Java  reference app for the AndroidBeaconLibrary

## Project Setup

1. Install [Android Studio](https://developer.android.com/sdk/installing/studio.html) 4.1+
2. Open this project

See the [Kotlin version of the reference app here.](https://github.com/davidgyoung/android-beacon-library-reference-kotlin)
