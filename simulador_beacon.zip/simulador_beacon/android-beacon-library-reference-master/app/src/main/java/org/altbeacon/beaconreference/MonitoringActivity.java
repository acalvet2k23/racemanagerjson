package org.altbeacon.beaconreference;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.altbeacon.beacon.Beacon;
import org.altbeacon.beacon.BeaconManager;
import org.altbeacon.beacon.BeaconParser;
import org.altbeacon.beacon.BeaconTransmitter;
import org.altbeacon.beacon.MonitorNotifier;
import org.altbeacon.beacon.Region;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author dyoung
 * @author Matt Tyler
 */
public class MonitoringActivity extends Activity {
	protected static final String TAG = "MonitoringActivity";
	public static boolean toggle = false;
	public static List<BeaconTransmitter> transmitters = new ArrayList<>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		Log.d(TAG, "onCreate");
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_monitoring);
		Button start = findViewById(R.id.enableButton);
		TextView tv = findViewById(R.id.textView1);
		start.setOnClickListener(view -> {
			tv.setText("");
			if (toggle){
				for (BeaconTransmitter transmitter : transmitters){
					if (transmitter.isStarted()){
						transmitter.stopAdvertising();
					}
				}
				tv.append("Number of beacons: "+transmitters.size());
				toggle = false;
			}else{
				for (BeaconTransmitter transmitter : transmitters){
					transmitter.startAdvertising();
				}
				toggle = true;
			}

		});


		Beacon beacon = new Beacon.Builder()
				.setId1("2f234454-cf6d-4a0f-adf2-f4911ba9ffa6")
				.setId2("1")
				.setId3("2")
				.setManufacturer(0x0118)
				.setTxPower(-59)
				.setDataFields(Arrays.asList(new Long[] {0l}))
				.build();
		BeaconParser beaconParser = new BeaconParser()
				.setBeaconLayout("m:2-3=beac,i:4-19,i:20-21,i:22-23,p:24-24,d:25-25");
		BeaconTransmitter beaconTransmitter = new BeaconTransmitter(getApplicationContext(), beaconParser);
		beaconTransmitter.setBeacon(beacon);
		transmitters.add(beaconTransmitter);


	}

}
